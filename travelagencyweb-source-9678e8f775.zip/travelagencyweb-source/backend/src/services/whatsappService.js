/**
 * WhatsApp Service — provider abstraction with console fallback
 * Supports: Twilio WhatsApp, WhatsApp Business Cloud API, WasenderAPI
 *
 * Env vars:
 * - WHATSAPP_PROVIDER (twilio | meta | wasender | console)
 * - WHATSAPP_FROM_NUMBER (Twilio WhatsApp number, e.g. whatsapp:+14155238886)
 * - META_WHATSAPP_TOKEN (Meta Cloud API token)
 * - META_WHATSAPP_PHONE_ID (Meta phone number ID)
 * - WASENDER_API_KEY (WasenderAPI key from wasenderapi.com)
 * - WASENDER_INSTANCE_ID (WasenderAPI instance/session ID)
 */

const { PrismaClient } = require("@prisma/client");
const { getPlanLimit } = require("../lib/planFeatures");
const _prisma = new PrismaClient();

const WHATSAPP_PROVIDER = () => process.env.WHATSAPP_PROVIDER || "console";

// Per-tenant monthly WhatsApp quota (e.g. Pro = 200/mo, Business/Ultimate = unlimited).
async function _withinWhatsAppQuota(tenantId) {
  if (!tenantId) return true;
  try {
    const tenant = await _prisma.tenant.findUnique({ where: { id: tenantId }, select: { subscriptionPlan: true } });
    const limit = getPlanLimit(tenant?.subscriptionPlan, "whatsapp");
    if (limit === -1) return true;              // unlimited
    if (!limit || limit <= 0) return false;     // 0 / undefined → not allowed
    const start = new Date();
    start.setUTCDate(1); start.setUTCHours(0, 0, 0, 0);
    const used = await _prisma.whatsAppLog.count({ where: { tenantId, status: "sent", createdAt: { gte: start } } });
    return used < limit;
  } catch {
    return true; // fail-open: never block a send because the counter errored
  }
}

async function _saveLog({ to, message, result, tenantId, templateType, createdByUserId }) {
  try {
    await _prisma.whatsAppLog.create({
      data: {
        id: require("crypto").randomUUID(),
        tenantId: tenantId || null,
        phone: to,
        message,
        status: result.success ? "sent" : "failed",
        provider: result.provider || "unknown",
        errorMessage: result.error || null,
        providerMessageId: result.messageId || null,
        templateType: templateType || null,
        createdByUserId: createdByUserId || null,
        sentAt: result.success ? new Date() : null,
      },
    });
  } catch (e) {
    console.error("[WHATSAPP-LOG] Failed to save log:", e.message);
  }
}

/**
 * Send a WhatsApp message. Falls back to console.log if provider not configured.
 * @param {{ to: string, message: string, templateName?: string, templateParams?: string[], tenantId?: string, templateType?: string, createdByUserId?: string }} opts
 */
async function sendWhatsApp({ to, message, templateName, templateParams, tenantId, templateType, createdByUserId }) {
  // Enforce the plan's monthly WhatsApp quota before spending a message.
  if (tenantId && !(await _withinWhatsAppQuota(tenantId))) {
    const result = { success: false, provider: "quota", error: "WhatsApp monthly limit reached", limitReached: true };
    await _saveLog({ to, message, result, tenantId, templateType, createdByUserId });
    return result;
  }

  const provider = WHATSAPP_PROVIDER();
  let result;

  if (provider === "twilio") {
    result = await sendViaTwilioWhatsApp(to, message);
  } else if (provider === "meta") {
    result = await sendViaMetaWhatsApp(to, message, templateName, templateParams);
  } else if (provider === "wasender") {
    result = await sendViaWasender(to, message);
  } else {
    // Console fallback
    console.log(`[WHATSAPP-LOG] To: ${to} | Message: ${message}`);
    result = { success: true, provider: "console", messageId: `WA-LOG-${Date.now()}` };
  }

  await _saveLog({ to, message, result, tenantId, templateType, createdByUserId });
  return result;
}

async function sendViaTwilioWhatsApp(to, message) {
  try {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.WHATSAPP_FROM_NUMBER || "whatsapp:+14155238886";

    if (!accountSid || !authToken) {
      console.log(`[WHATSAPP-LOG] Twilio not configured. To: ${to} | Message: ${message}`);
      return { success: false, provider: "twilio", error: "Twilio credentials not configured" };
    }

    const whatsappTo = to.startsWith("whatsapp:") ? to : `whatsapp:${to}`;
    const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: "Basic " + Buffer.from(`${accountSid}:${authToken}`).toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({ To: whatsappTo, From: from, Body: message }),
    });
    const data = await res.json();

    if (data.sid) {
      return { success: true, provider: "twilio-whatsapp", messageId: data.sid };
    }
    return { success: false, provider: "twilio-whatsapp", error: data.message || "Failed" };
  } catch (err) {
    return { success: false, provider: "twilio-whatsapp", error: err.message };
  }
}

async function sendViaMetaWhatsApp(to, message, templateName, templateParams) {
  try {
    const token = process.env.META_WHATSAPP_TOKEN;
    const phoneId = process.env.META_WHATSAPP_PHONE_ID;

    if (!token || !phoneId) {
      console.log(`[WHATSAPP-LOG] Meta WhatsApp not configured. To: ${to} | Message: ${message}`);
      return { success: false, provider: "meta", error: "META_WHATSAPP_TOKEN and META_WHATSAPP_PHONE_ID required" };
    }

    const cleanNumber = to.replace(/[^0-9]/g, "");

    // If template-based message
    const body = templateName
      ? {
          messaging_product: "whatsapp",
          to: cleanNumber,
          type: "template",
          template: {
            name: templateName,
            language: { code: "en" },
            components: templateParams ? [{ type: "body", parameters: templateParams.map(p => ({ type: "text", text: p })) }] : [],
          },
        }
      : {
          messaging_product: "whatsapp",
          to: cleanNumber,
          type: "text",
          text: { body: message },
        };

    const res = await fetch(`https://graph.facebook.com/v18.0/${phoneId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();

    if (data.messages?.[0]?.id) {
      return { success: true, provider: "meta-whatsapp", messageId: data.messages[0].id };
    }
    return { success: false, provider: "meta-whatsapp", error: data.error?.message || "Failed" };
  } catch (err) {
    return { success: false, provider: "meta-whatsapp", error: err.message };
  }
}

async function sendViaWasender(to, message) {
  try {
    const apiKey = process.env.WASENDER_API_KEY;

    if (!apiKey) {
      console.log(`[WHATSAPP-LOG] WasenderAPI not configured. To: ${to} | Message: ${message}`);
      return { success: false, provider: "wasender", error: "WASENDER_API_KEY required" };
    }

    // Normalize to Bangladesh number: 8801XXXXXXXXX
    const digits = String(to).replace(/[^0-9]/g, "");
    let phone = digits;
    if (digits.startsWith("0") && digits.length === 11) phone = `88${digits}`;
    else if (!digits.startsWith("880")) phone = `880${digits}`;

    const res = await fetch(`https://wasenderapi.com/api/send-message`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ to: phone, type: "text", text: message }),
    });

    const data = await res.json();

    if (data?.id || data?.success || data?.status === "sent") {
      return { success: true, provider: "wasender", messageId: data.id || `WA-${Date.now()}` };
    }
    // Rate limit hit — log and treat as non-fatal
    if (data?.retry_after) {
      console.warn(`[WASENDER] Rate limited. Retry after ${data.retry_after}s`);
      return { success: false, provider: "wasender", error: `Rate limited. Retry after ${data.retry_after}s` };
    }
    return { success: false, provider: "wasender", error: data?.message || "Failed to send" };
  } catch (err) {
    return { success: false, provider: "wasender", error: err.message };
  }
}

function getWhatsAppConfig() {
  const provider = WHATSAPP_PROVIDER();
  return {
    provider,
    configured: isWhatsAppConfigured(provider),
    wasenderKeyConfigured: Boolean(process.env.WASENDER_API_KEY),
    metaPhoneId: process.env.META_WHATSAPP_PHONE_ID || "",
    twilioFrom: process.env.WHATSAPP_FROM_NUMBER || "",
  };
}

function isWhatsAppConfigured(provider) {
  if (provider === "wasender") return Boolean(process.env.WASENDER_API_KEY);
  if (provider === "meta") return Boolean(process.env.META_WHATSAPP_TOKEN && process.env.META_WHATSAPP_PHONE_ID);
  if (provider === "twilio") return Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN);
  return false;
}

module.exports = { sendWhatsApp, getWhatsAppConfig };
