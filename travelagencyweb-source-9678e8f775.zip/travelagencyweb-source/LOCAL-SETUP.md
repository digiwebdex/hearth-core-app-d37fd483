# TravelAgencyWeb — Local Setup (VS Code)

This is a clean source snapshot. **`node_modules`, build output, and all secret `.env` files were removed** — you install dependencies and create your own `.env` locally.

## What's inside
- `src/` … React + Vite + TypeScript frontend
- `backend/` … Express + Prisma API (`backend/src`, `backend/prisma/schema.prisma`)
- `app/`, `vps/`, `scripts/` … Docker / deployment configs (optional)
- `SYSTEM-MASTER-AUDIT.md` … full architecture documentation
- `docs/` … organogram image + guides

## Prerequisites
- Node.js 18+ (20 recommended) and npm
- PostgreSQL 16 running locally (or Docker)

## 1. Frontend
```bash
npm install
cp .env.example .env          # then edit values (see file comments)
npm run dev                   # Vite dev server (http://localhost:5173)
```

## 2. Backend
```bash
cd backend
npm install
cp .env.example .env          # set DATABASE_URL + JWT_SECRET (min 32 chars)
# generate a JWT secret:  openssl rand -hex 32
npx prisma generate
npx prisma migrate deploy     # apply schema to your local Postgres
#   (first-time empty DB) or:  npx prisma db push
npm run dev                   # API on http://localhost:4000 (see backend/.env PORT)
```

## 3. Point the frontend at your API
Set the API base URL in the root `.env` (see `VITE_API_URL` / equivalent in `.env.example`).

## 4. Tests
```bash
npm run build && npx vitest run   # frontend
cd backend && npm test            # backend
```

## Notes
- The `.env.example` files list every variable (DB, JWT, bKash, SSLCommerz, SMS, WhatsApp, Telegram, SMTP). Fill only what you need locally — payments/SMS/WhatsApp are optional for dev.
- No production credentials are included. Create fresh dev credentials.
- Full endpoint/model/permission reference: see **SYSTEM-MASTER-AUDIT.md**.
